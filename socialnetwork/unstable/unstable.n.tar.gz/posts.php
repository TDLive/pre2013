<?php if(!isset($lin)){ header('Location: socialnetwork.php?p=login'); } ?>
