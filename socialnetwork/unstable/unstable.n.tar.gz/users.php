<?php die('do not access this file directly please'); ?>
adm,change_me_please
